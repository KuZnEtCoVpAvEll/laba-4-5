﻿using Pr5.Spells;
using System;
using System.Net.Http.Headers;

namespace Pr5
{
    public class Program
    {
        static void Main(string[] args)     
        {
            Game game = new Game();
            game.StartGame();
        }

    }
}